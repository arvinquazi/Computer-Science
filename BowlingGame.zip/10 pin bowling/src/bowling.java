import java.util.Scanner;
public class bowling {
    public static void main(String[] args) {
        int ball1 = 0;
        int ball2 = 0;
        Scanner kbInp = new Scanner(System.in);

        System.out.println("Welcome to 10-pin bowling");
        System.out.println("How many pins did you knock down with your first ball?");

        ball1 = kbInp.nextInt();
        System.out.println("How many pins did you knock down with your second ball?");
        ball2 = kbInp.nextInt();

        int r1final = ball1 + ball2;
        System.out.println("Your score is " + (r1final));


        System.out.println("-----------");
        System.out.println("  Round 2  ");
        System.out.println("-----------");

        int ball1r2 = 0;
        int ball2r2 = 0;
        System.out.println("How many pins did you knock down with your first ball?");
        ball1r2 = kbInp.nextInt();
        System.out.println("How many pins did you knock down with your second ball?");
        ball2r2 = kbInp.nextInt();

        int sum2 = r1final + ball1r2;
        System.out.println("Your score is " + (sum2));

        System.out.println("-----------");
        System.out.println("  Round 3  ");
        System.out.println("-----------");

        int ball1r3 = 0;
        int ball2r3 = 0;
        System.out.println("How many pins did you knock down with your first ball?");
        ball1r3 = kbInp.nextInt();
        System.out.println("How many pins did you knock down with your second ball?");
        ball2r3 = kbInp.nextInt();
        int sum3 = sum2 + ball2r2 +ball1r3;
        System.out.println("Your score is " + (sum3));

        System.out.println("-----------");
        System.out.println("  Round 4 ");
        System.out.println("-----------");

        int ball1r4 = 0;
        int ball2r4 = 0;
        System.out.println("How many pins did you knock down with your first ball?");
        ball1r4 = kbInp.nextInt();
        System.out.println("How many pins did you knock down with your second ball?");
        ball2r4 = kbInp.nextInt();
        int sum4 = sum3 + sum2 + ball2r2 +ball1r3;
        System.out.println("Your score is " + (sum4));

        System.out.println("-----------");
        System.out.println("  Round 5 ");
        System.out.println("-----------");

        int ball1r5 = 0;
        int ball2r5 = 0;
        System.out.println("How many pins did you knock down with your first ball?");
        ball1r5 = kbInp.nextInt();
        System.out.println("How many pins did you knock down with your second ball?");
        ball2r5 = kbInp.nextInt();
        int sum5 = sum4 + sum3 + sum2 + ball2r2+ball1r3;
        System.out.println("Your score is " + sum5);

        System.out.println("-----------");
        System.out.println("  Round 6 ");
        System.out.println("-----------");

        int ball1r6 = 0;
        int ball2r6 = 0;
        System.out.println("How many pins did you knock down with your first ball?");
        ball1r6 = kbInp.nextInt();
        System.out.println("How many pins did you knock down with your second ball?");
        ball2r6 = kbInp.nextInt();
        int sum6 = sum5 + sum3 + sum2 + ball2r2+ball1r3;
        System.out.println("Your score is " + sum6);

        System.out.println("-----------");
        System.out.println("  Round 7 ");
        System.out.println("-----------");

        int ball1r7 = 0;
        int ball2r7 = 0;
        System.out.println("How many pins did you knock down with your first ball?");
        ball1r7 = kbInp.nextInt();
        System.out.println("How many pins did you knock down with your second ball?");
        ball2r7 = kbInp.nextInt();
        int sum7 = sum5 + sum4 + sum3 + sum2 + ball2r2+ball1r3;
        System.out.println("Your score is " + sum7);

        System.out.println("-----------");
        System.out.println("  Round 8 ");
        System.out.println("-----------");

        int ball1r8 = 0;
        int ball2r8 = 0;
        System.out.println("How many pins did you knock down with your first ball?");
        ball1r8 = kbInp.nextInt();
        System.out.println("How many pins did you knock down with your second ball?");
        ball2r8 = kbInp.nextInt();
        int sum8 = sum7 + sum6 + sum5 + sum4 + sum3 + sum2 + ball2r2+ball1r3;
        System.out.println("Your score is " + sum8);

        System.out.println("-----------");
        System.out.println("  Round 9 ");
        System.out.println("-----------");

        int ball1r9 = 0;
        int ball2r9 = 0;
        System.out.println("How many pins did you knock down with your first ball?");
        ball1r9 = kbInp.nextInt();
        System.out.println("How many pins did you knock down with your second ball?");
        ball2r9 = kbInp.nextInt();
        int sum9 = sum8 + sum7 + sum6 + sum5 + sum4 + sum3 + sum2 + ball2r2+ball1r3;
        System.out.println("Your score is " + sum9);

        System.out.println("-----------");
        System.out.println("  Round 10 ");
        System.out.println("-----------");

        int ball1r10 = 0;
        int ball2r10 = 0;
        System.out.println("How many pins did you knock down with your first ball?");
        ball1r10 = kbInp.nextInt();
        System.out.println("How many pins did you knock down with your second ball?");
        ball2r10 = kbInp.nextInt();
        int sum10 = sum9 +sum8 + sum7 + sum6 + sum5 + sum4 + sum3 + sum2 + ball2r2+ball1r3 + ball2r10;
        System.out.println("Congratulations, your final score is " + sum10);


    }
}
